# Car-Performance-Prediction
This project is aimed at predicting car's mileage (mpg) using a dataset which contains multiple features like car name, horsepower, number of cylinders and many more.
